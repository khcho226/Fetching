package com.example.serverpractice

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.firebase.storage.FirebaseStorage
import java.io.ByteArrayOutputStream
import java.io.File


class MainActivity : AppCompatActivity() {

    private val TAG = "MainActivity"
    private val REQUEST_CODE = 1000

    private lateinit var imageView: ImageView

    val storage by lazy { FirebaseStorage.getInstance() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView = findViewById<ImageView>(R.id.imageView)

        findViewById<Button>(R.id.button).setOnClickListener {

            // ImageView 에 저장된 image 를 Bitmap 으로 전환하기 위한 과정

            imageView.isDrawingCacheEnabled = true
            imageView.buildDrawingCache()

            val bitmap = (imageView.drawable as BitmapDrawable).bitmap
            val baos = ByteArrayOutputStream()

            // bitmap 을 압축하여 baos 에 stream
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
            // baos 의 데이터를 ByteArray 로 전환하여 data 에 저장
            val data = baos.toByteArray()
            val storageRef = storage.reference.child("images/4444.jpg")

            // Storage path 에 data 저장

            storageRef.putBytes(data).addOnCompleteListener {
                // exception 이 null 이 아닌 경우에는 업로드 실패
                // 원인은 printStackTrace() 에서 확인해야 함
                if (it.exception != null) {
                    Log.d(TAG, "업로드 실패")
                    it.exception?.printStackTrace()

                } else {
                    Log.d(TAG, "업로드 성공")
                }
            }



        }
    }
}

        ////// download 기능
        /*findViewById<Button>(R.id.button).setOnClickListener {
            업로드 한 text.jpg 의 http 경로를 가져오는 함수만 작성.

            imageView.isDrawingCacheEnabled = true
            imageView.buildDrawingCache()

            val bitmap = (imageView.drawable as BitmapDrawable).bitmap
            val baos = ByteArrayOutputStream()
            // bitmap 을 압축하여 baos에

            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
            // baos 의 데이터를 ByteArray 로 전환하여 data 에 저장
            val data = baos.toByteArray()

            val storageRef = storage.reference.child("images/4444.jpg")
            storageRef.downloadUrl.addOnCompleteListener {
                if (it.exception != null) {
                    it.exception?.printStackTrace()

                } else {
                    Log.d(TAG, it.result!!.toString())
                    Glide
                        .with(this) // it과 this의 차이는 무엇?
                        .load(it.result!!.toString())
                        .into(findViewById<ImageView>(R.id.imageView2));
                }
            }
        } */


    /*override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.d(TAG, "onActivityResult: requestCode: ${requestCode}, resultCode: ${resultCode}, data: ${data == null}")

        if (requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val thumbnail: Bitmap = data?.getParcelableExtra<Bitmap>("data") ?: return
            Log.d(TAG, "onActivityResult")
        }
    }*/
